"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdate_N_E"]("middleware",{

/***/ "(middleware)/./lib/i18n.ts":
/*!*********************!*\
  !*** ./lib/i18n.ts ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   defaultLocale: () => (/* binding */ defaultLocale),\n/* harmony export */   getTranslations: () => (/* binding */ getTranslations),\n/* harmony export */   locales: () => (/* binding */ locales),\n/* harmony export */   translations: () => (/* binding */ translations)\n/* harmony export */ });\n/* harmony import */ var _i18n_nl_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @/i18n/nl.json */ \"(middleware)/./i18n/nl.json\");\n/* harmony import */ var _i18n_fr_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @/i18n/fr.json */ \"(middleware)/./i18n/fr.json\");\n/* harmony import */ var _i18n_en_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @/i18n/en.json */ \"(middleware)/./i18n/en.json\");\n\n\n\nconst locales = [\n    \"nl\",\n    \"fr\",\n    \"en\"\n];\nconst defaultLocale = \"nl\";\nconst translations = {\n    nl: _i18n_nl_json__WEBPACK_IMPORTED_MODULE_0__,\n    fr: _i18n_fr_json__WEBPACK_IMPORTED_MODULE_1__,\n    en: _i18n_en_json__WEBPACK_IMPORTED_MODULE_2__\n};\nfunction getTranslations(locale) {\n    return translations[locale];\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKG1pZGRsZXdhcmUpLy4vbGliL2kxOG4udHMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUE0QztBQUNBO0FBQ0E7QUFFckMsTUFBTUcsVUFBVTtJQUFDO0lBQU07SUFBTTtDQUFLLENBQVU7QUFFNUMsTUFBTUMsZ0JBQXdCLEtBQUs7QUFFbkMsTUFBTUMsZUFBZTtJQUMxQkMsSUFBSU4sMENBQWNBO0lBQ2xCTyxJQUFJTiwwQ0FBY0E7SUFDbEJPLElBQUlOLDBDQUFjQTtBQUNwQixFQUFFO0FBRUssU0FBU08sZ0JBQWdCQyxNQUFjO0lBQzVDLE9BQU9MLFlBQVksQ0FBQ0ssT0FBTztBQUM3QiIsInNvdXJjZXMiOlsid2VicGFjazovL19OX0UvLi9saWIvaTE4bi50cz80OWFlIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBubFRyYW5zbGF0aW9ucyBmcm9tICdAL2kxOG4vbmwuanNvbic7XG5pbXBvcnQgZnJUcmFuc2xhdGlvbnMgZnJvbSAnQC9pMThuL2ZyLmpzb24nO1xuaW1wb3J0IGVuVHJhbnNsYXRpb25zIGZyb20gJ0AvaTE4bi9lbi5qc29uJztcblxuZXhwb3J0IGNvbnN0IGxvY2FsZXMgPSBbJ25sJywgJ2ZyJywgJ2VuJ10gYXMgY29uc3Q7XG5leHBvcnQgdHlwZSBMb2NhbGUgPSB0eXBlb2YgbG9jYWxlc1tudW1iZXJdO1xuZXhwb3J0IGNvbnN0IGRlZmF1bHRMb2NhbGU6IExvY2FsZSA9ICdubCc7XG5cbmV4cG9ydCBjb25zdCB0cmFuc2xhdGlvbnMgPSB7XG4gIG5sOiBubFRyYW5zbGF0aW9ucyxcbiAgZnI6IGZyVHJhbnNsYXRpb25zLFxuICBlbjogZW5UcmFuc2xhdGlvbnMsXG59O1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0VHJhbnNsYXRpb25zKGxvY2FsZTogTG9jYWxlKSB7XG4gIHJldHVybiB0cmFuc2xhdGlvbnNbbG9jYWxlXTtcbn1cbiJdLCJuYW1lcyI6WyJubFRyYW5zbGF0aW9ucyIsImZyVHJhbnNsYXRpb25zIiwiZW5UcmFuc2xhdGlvbnMiLCJsb2NhbGVzIiwiZGVmYXVsdExvY2FsZSIsInRyYW5zbGF0aW9ucyIsIm5sIiwiZnIiLCJlbiIsImdldFRyYW5zbGF0aW9ucyIsImxvY2FsZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(middleware)/./lib/i18n.ts\n");

/***/ }),

/***/ "(middleware)/./i18n/en.json":
/*!**********************!*\
  !*** ./i18n/en.json ***!
  \**********************/
/***/ ((module) => {

module.exports = JSON.parse('{"brand":{"name":"RenoVapro","tagline":"Professional Renovation in Ghent"},"nav":{"home":"Home","services":"Services","about":"About Us","contact":"Contact","login":"Login","platform":"Platform"},"hero":{"title":"Professional Renovation in Ghent","subtitle":"From tiling to bathroom renovations - Your specialist for quality construction","cta":"Request Quote","ctaPlatform":"Open Platform","secondary":"Our Services"},"platform":{"title":"RenoVapro Platform","subtitle":"Manage your projects, teams, and clients","tabProjects":"Projects","tabTeam":"Team","tabClients":"Clients","tabReports":"Reports","placeholder":"Platform functionality coming soon"},"auth":{"title":"Sign In","subtitle":"Log in to your RenoVapro account","email":"Email address","password":"Password","login":"Log In","signup":"Sign Up","forgotPassword":"Forgot password?","placeholder":"Authentication functionality coming in Step 2"},"footer":{"company":"Company","contact":"Contact","legal":"Legal","about":"About Us","services":"Services","careers":"Careers","phone":"Phone","email":"Email","location":"Location","privacy":"Privacy Policy","terms":"Terms","copyright":"© 2025 RenoVapro. All rights reserved."}}');

/***/ }),

/***/ "(middleware)/./i18n/fr.json":
/*!**********************!*\
  !*** ./i18n/fr.json ***!
  \**********************/
/***/ ((module) => {

module.exports = JSON.parse('{"brand":{"name":"RenoVapro","tagline":"Rénovation Professionnelle à Gand"},"nav":{"home":"Accueil","services":"Services","about":"À Propos","contact":"Contact","login":"Connexion","platform":"Plateforme"},"hero":{"title":"Rénovation Professionnelle à Gand","subtitle":"Du carrelage aux rénovations de salles de bains - Votre spécialiste pour des travaux de qualité","cta":"Demander un Devis","ctaPlatform":"Ouvrir la Plateforme","secondary":"Nos Services"},"platform":{"title":"Plateforme RenoVapro","subtitle":"Gérez vos projets, équipes et clients","tabProjects":"Projets","tabTeam":"Équipe","tabClients":"Clients","tabReports":"Rapports","placeholder":"Fonctionnalité de plateforme à venir"},"auth":{"title":"Connexion","subtitle":"Connectez-vous à votre compte RenoVapro","email":"Adresse e-mail","password":"Mot de passe","login":"Se Connecter","signup":"S\'inscrire","forgotPassword":"Mot de passe oublié?","placeholder":"Fonctionnalité d\'authentification arrive à l\'étape 2"},"footer":{"company":"Entreprise","contact":"Contact","legal":"Légal","about":"À Propos","services":"Services","careers":"Carrières","phone":"Téléphone","email":"Email","location":"Localisation","privacy":"Politique de Confidentialité","terms":"Conditions","copyright":"© 2025 RenoVapro. Tous droits réservés."}}');

/***/ }),

/***/ "(middleware)/./i18n/nl.json":
/*!**********************!*\
  !*** ./i18n/nl.json ***!
  \**********************/
/***/ ((module) => {

module.exports = JSON.parse('{"brand":{"name":"RenoVapro","tagline":"Professionele Renovatie in Gent"},"nav":{"home":"Home","services":"Diensten","about":"Over Ons","contact":"Contact","login":"Inloggen","platform":"Platform"},"hero":{"title":"Professionele Renovatie in Gent","subtitle":"Van tegelwerk tot badkamerrenovaties - Uw specialist voor kwaliteitsvolle verbouwingen","cta":"Offerte Aanvragen","ctaPlatform":"Open Platform","secondary":"Onze Diensten"},"platform":{"title":"RenoVapro Platform","subtitle":"Beheer uw projecten, teams en klanten","tabProjects":"Projecten","tabTeam":"Team","tabClients":"Klanten","tabReports":"Rapporten","placeholder":"Platform functionaliteit komt binnenkort"},"auth":{"title":"Aanmelden","subtitle":"Log in op uw RenoVapro account","email":"E-mailadres","password":"Wachtwoord","login":"Inloggen","signup":"Registreren","forgotPassword":"Wachtwoord vergeten?","placeholder":"Authenticatie functionaliteit komt in Stap 2"},"footer":{"company":"Bedrijf","contact":"Contact","legal":"Juridisch","about":"Over Ons","services":"Diensten","careers":"Vacatures","phone":"Telefoon","email":"Email","location":"Locatie","privacy":"Privacy Beleid","terms":"Voorwaarden","copyright":"© 2025 RenoVapro. Alle rechten voorbehouden."}}');

/***/ })

});